package project;

import java.util.Scanner;

public class Fto_C {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner ac = new Scanner(System.in);
		int n;
		double f, c;

		System.out.println("===============");
		System.out.println("1. 화씨 -> 섭씨");
		System.out.println("2. 섭씨 -> 화씨");
		System.out.println("===============");

		System.out.print("번호를 선택하시오: ");
		n = ac.nextInt();
	    if (n == 1) {
		System.out.print("화씨온도를 입력하시오: ");
		f = ac.nextDouble();
		c = 5*(f-32)/9;
		System.out.print("섭씨온도는 " + c + " 입니다"); }
		
	    else if ( n == 2) {
		System.out.print("섭씨온도를 입력하시오: ");
		c = ac.nextDouble();
		f = (9*c/5)+32;
		System.out.print("화씨온도는 " + f + " 입니다"); }
	    
	    else {
	    System.out.println("유효하지 않은 입력값입니다."); }
	    
	    ac.close(); 
	    }
}
