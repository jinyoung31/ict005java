package week1;

public class Hello2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("안녕하세요?"); 
		System.out.println("자바를 처음 공부합니다");
		System.out.println("자바는 재미있나요?");

	}

}
